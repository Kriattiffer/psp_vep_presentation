utildir = sprintf('%s\\utilities',pwd);
path(path,utildir);